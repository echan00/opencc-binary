var searchData=
[
  ['opencc_20c_20api',['OpenCC C API',['../group__opencc__c__api.html',1,'']]],
  ['opencc_20c_2b_2b_20comprehensive_20api',['OpenCC C++ Comprehensive API',['../group__opencc__cpp__api.html',1,'']]],
  ['opencc_20c_2b_2b_20simple_20api',['OpenCC C++ Simple API',['../group__opencc__simple__api.html',1,'']]]
];
