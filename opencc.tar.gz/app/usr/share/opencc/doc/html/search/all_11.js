var searchData=
[
  ['textdict',['TextDict',['../classopencc_1_1_text_dict.html',1,'opencc::TextDict'],['../classopencc_1_1_text_dict.html#a853bbb425460e21199d934b6dc518b97',1,'opencc::TextDict::TextDict()']]],
  ['textdicttestbase',['TextDictTestBase',['../classopencc_1_1_text_dict_test_base.html',1,'opencc']]],
  ['truncateutf8',['TruncateUTF8',['../classopencc_1_1_u_t_f8_util.html#ae212d8ca540b33752e2ff373f842479c',1,'opencc::UTF8Util']]]
];
