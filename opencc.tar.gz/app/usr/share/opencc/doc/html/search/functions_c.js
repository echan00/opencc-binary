var searchData=
[
  ['serializetofile',['SerializeToFile',['../classopencc_1_1_binary_dict.html#a99e3982993ce0c2162c66559e054370e',1,'opencc::BinaryDict::SerializeToFile()'],['../classopencc_1_1_darts_dict.html#a835ab0c2b4ccaa7e586cecbcb2d417ae',1,'opencc::DartsDict::SerializeToFile()'],['../classopencc_1_1_serializable_dict.html#acb184b20e1f9eaee02905809cf259e5f',1,'opencc::SerializableDict::SerializeToFile(FILE *fp) const =0'],['../classopencc_1_1_serializable_dict.html#ac9b353c5ffd930744cdeed1d39431eb3',1,'opencc::SerializableDict::SerializeToFile(const string &amp;fileName) const'],['../classopencc_1_1_text_dict.html#a020f7973b33d4430c7a0e4ee474d44a8',1,'opencc::TextDict::SerializeToFile()']]],
  ['simpleconverter',['SimpleConverter',['../classopencc_1_1_simple_converter.html#a6e18e21f772ed986fb5ff89f6576dad4',1,'opencc::SimpleConverter']]],
  ['skiputf8bom',['SkipUtf8Bom',['../classopencc_1_1_u_t_f8_util.html#a2c755b77ec792c825880b07c8ec2f788',1,'opencc::UTF8Util']]]
];
