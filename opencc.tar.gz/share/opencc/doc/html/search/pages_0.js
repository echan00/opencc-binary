var searchData=
[
  ['open_20chinese_20convert_20開放中文轉換',['Open Chinese Convert 開放中文轉換',['../index.html',1,'']]]
];
