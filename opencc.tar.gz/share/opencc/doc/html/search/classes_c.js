var searchData=
[
  ['segmentation',['Segmentation',['../classopencc_1_1_segmentation.html',1,'opencc']]],
  ['segments',['Segments',['../classopencc_1_1_segments.html',1,'opencc']]],
  ['serializabledict',['SerializableDict',['../classopencc_1_1_serializable_dict.html',1,'opencc']]],
  ['shouldnotbehere',['ShouldNotBeHere',['../classopencc_1_1_should_not_be_here.html',1,'opencc']]],
  ['signals',['Signals',['../structopencc_1_1_phrase_extract_1_1_signals.html',1,'opencc::PhraseExtract']]],
  ['simpleconverter',['SimpleConverter',['../classopencc_1_1_simple_converter.html',1,'opencc']]],
  ['singlevaluedictentry',['SingleValueDictEntry',['../classopencc_1_1_single_value_dict_entry.html',1,'opencc']]],
  ['strmultivaluedictentry',['StrMultiValueDictEntry',['../classopencc_1_1_str_multi_value_dict_entry.html',1,'opencc']]],
  ['strsinglevaluedictentry',['StrSingleValueDictEntry',['../classopencc_1_1_str_single_value_dict_entry.html',1,'opencc']]]
];
