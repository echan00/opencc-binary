var searchData=
[
  ['length',['Length',['../classopencc_1_1_u_t_f8_util.html#ac0642244a71d77d3e79829a7952f9b86',1,'opencc::UTF8Util']]],
  ['lexicon',['Lexicon',['../classopencc_1_1_lexicon.html',1,'opencc']]]
];
