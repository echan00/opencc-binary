var searchData=
[
  ['cmdlineoutput',['CmdLineOutput',['../class_cmd_line_output.html',1,'']]],
  ['config',['Config',['../classopencc_1_1_config.html',1,'opencc']]],
  ['configtestbase',['ConfigTestBase',['../classopencc_1_1_config_test_base.html',1,'opencc']]],
  ['conversion',['Conversion',['../classopencc_1_1_conversion.html',1,'opencc']]],
  ['conversionchain',['ConversionChain',['../classopencc_1_1_conversion_chain.html',1,'opencc']]],
  ['convert',['Convert',['../classopencc_1_1_simple_converter.html#a6d04f4a390d8313c88dd7442d2b56f2c',1,'opencc::SimpleConverter::Convert(const std::string &amp;input) const '],['../classopencc_1_1_simple_converter.html#aec728e1aeb73359402b70a28d7b1a7fb',1,'opencc::SimpleConverter::Convert(const char *input) const '],['../classopencc_1_1_simple_converter.html#aff8add72393039b8e6a5bcaae70a8dbe',1,'opencc::SimpleConverter::Convert(const char *input, size_t length) const '],['../classopencc_1_1_simple_converter.html#a8a50ba4810fbb05153cf3dc7114bccc9',1,'opencc::SimpleConverter::Convert(const char *input, char *output) const '],['../classopencc_1_1_simple_converter.html#a8e655cd61adf95de36e2ac73d7c94a30',1,'opencc::SimpleConverter::Convert(const char *input, size_t length, char *output) const ']]],
  ['convertdictionary',['ConvertDictionary',['../group__opencc__cpp__api.html#gab218db32cfc24e275b00e7dbd26c00c3',1,'opencc']]],
  ['converter',['Converter',['../classopencc_1_1_converter.html',1,'opencc']]]
];
