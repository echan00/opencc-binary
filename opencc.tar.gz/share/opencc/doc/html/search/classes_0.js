var searchData=
[
  ['binarydict',['BinaryDict',['../classopencc_1_1_binary_dict.html',1,'opencc']]]
];
